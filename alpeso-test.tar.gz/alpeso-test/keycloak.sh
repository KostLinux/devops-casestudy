#!/bin/bash

function err {
    echo "
    $error_message
    Usage: ./keycloak.sh <ClientID> <ClientSecret>
    "
}

CLIENT_ID=$1
CLIENT_SECRET=$2

# Base64 encode client credentials
ENCODED_CREDENTIALS=$(echo -n "${CLIENT_ID}:${CLIENT_SECRET}" | base64)

if [ -z "$CLIENT_ID" ] && [ -z "$CLIENT_SECRET" ]; then
    error_message="CLI options not defined"
    err
    exit 1
fi

if [ -z "$CLIENT_ID" ]; then
    error_message="Client ID not defined."
    err
    exit 1
fi

if [ -z "$CLIENT_SECRET" ]; then
    error_message="Client Secret not defined."
    err
    exit 1
fi

# Extract the access token
TOKEN=$(curl -k -H "Content-Type: application/x-www-form-urlencoded" \
        -H "Authorization: Basic $(echo -n ${CLIENTID}:${CLIENTSECRET} | base64 )" \
        --data "grant_type=client_credentials" \
        "http://mydomain.com/auth/realms/myrealm/protocol/openid-connect/token" -s | jq -r .access_token)

# Check if token was received
if [ "$TOKEN" == "" ]; then
  echo "Failed to obtain access token."
  exit 1
fi

echo "Authorization token is: $TOKEN"