# alpeso-test
alpeso-test

## How-to use

Simple run `./keycloak.sh <ClientID> <ClientSecret>`